export type IGenericErrorMessage = {
  path: string
  message: string
}
